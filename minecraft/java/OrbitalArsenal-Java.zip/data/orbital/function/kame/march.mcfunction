scoreboard players remove @s orbital.step 1
function orbital:kame/bore
summon marker ~ ~ ~ {Tags:["orbital.beam"]}
execute if score @s orbital.step matches 1.. positioned ^ ^ ^3 run function orbital:kame/march
execute if score @s orbital.step matches ..0 run function orbital:kame/impact
