particle explosion_emitter ~ ~ ~ 3 3 3 0 12 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 60 0.8
fill ~-8 ~-8 ~-8 ~8 ~8 ~8 air
