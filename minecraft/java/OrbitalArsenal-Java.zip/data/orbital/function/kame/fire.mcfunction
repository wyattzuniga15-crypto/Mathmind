scoreboard players set @s orbital.cd 160
title @s title {"text":"KA-ME-HA-ME-HAAA!","color":"aqua","bold":true}
playsound minecraft:entity.warden_sonic_boom master @a ~ ~ ~ 40 1.4
kill @e[type=marker,tag=orbital.beam]
scoreboard players set @s orbital.step 54
execute anchored eyes positioned ^ ^ ^2 run function orbital:kame/march
scoreboard players set #orbital orbital.beam 25
