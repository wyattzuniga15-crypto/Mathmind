execute at @e[type=marker,tag=orbital.beam] run function orbital:kame/glow
scoreboard players remove #orbital orbital.beam 1
execute if score #orbital orbital.beam matches ..0 run kill @e[type=marker,tag=orbital.beam]
