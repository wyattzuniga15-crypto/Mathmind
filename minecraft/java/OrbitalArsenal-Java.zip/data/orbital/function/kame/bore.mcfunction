# Three overlapping boxes rather than one cube: the union is an octagonal
# cross-section, which reads as a bored tunnel instead of a square corridor.
fill ~-5 ~-3 ~-5 ~5 ~3 ~5 air
fill ~-3 ~-5 ~-3 ~3 ~5 ~3 air
fill ~-4 ~-4 ~-4 ~4 ~4 ~4 air
