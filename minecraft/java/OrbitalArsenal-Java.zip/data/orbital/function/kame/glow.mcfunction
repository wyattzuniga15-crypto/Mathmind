# end_rod is the white-hot core, soul_fire_flame the blue sheath around it —
# both take no parameters, so neither depends on a particle argument format.
particle end_rod ~ ~ ~ 0.35 0.35 0.35 0 5 force
particle soul_fire_flame ~ ~ ~ 0.9 0.9 0.9 0.01 9 force
