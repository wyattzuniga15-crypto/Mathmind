# Right-clicking these three vanilla items is what fires each weapon. Reading a
# custom tag off the held item would be tidier, but the NBT path for that has
# moved between versions and a silent miss means the weapon simply never fires.
scoreboard objectives add orbital.cannon minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add orbital.nuke minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add orbital.kame minecraft.used:minecraft.goat_horn
scoreboard objectives add orbital.cd dummy
scoreboard objectives add orbital.range dummy
scoreboard objectives add orbital.step dummy
scoreboard objectives add orbital.stage dummy
scoreboard objectives add orbital.beam dummy
scoreboard players set #orbital orbital.stage 0
scoreboard players set #orbital orbital.beam 0
tellraw @a ["",{"text":"Orbital Arsenal ","color":"aqua","bold":true},{"text":"loaded — carrot on a stick = cannon, warped fungus on a stick = nuke, goat horn = kamehameha","color":"gray"}]
