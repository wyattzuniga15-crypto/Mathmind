scoreboard players add @a orbital.cd 0
scoreboard players remove @a[scores={orbital.cd=1..}] orbital.cd 1

execute as @a[scores={orbital.cannon=1..,orbital.cd=0}] at @s run function orbital:cannon/fire
execute as @a[scores={orbital.nuke=1..,orbital.cd=0}] at @s run function orbital:nuke/fire
execute as @a[scores={orbital.kame=1..,orbital.cd=0}] at @s run function orbital:kame/fire

scoreboard players set @a orbital.cannon 0
scoreboard players set @a orbital.nuke 0
scoreboard players set @a orbital.kame 0

# Work that spans ticks runs from a marker, because a scheduled function would
# come back positioned at the world origin instead of at the target.
execute if score #orbital orbital.stage matches 1.. run function orbital:nuke/dispatch
execute if score #orbital orbital.beam matches 1.. run function orbital:kame/draw
