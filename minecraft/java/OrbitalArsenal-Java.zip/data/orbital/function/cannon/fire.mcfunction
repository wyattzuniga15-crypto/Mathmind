scoreboard players set @s orbital.cd 200
title @s title {"text":"☄ ORBITAL STRIKE ☄","color":"red","bold":true}
title @s subtitle {"text":"Incoming: 300 TNT","color":"gold"}
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 50 0.6
function orbital:ray/cast
execute at @e[type=marker,tag=orbital.target,limit=1] run function orbital:cannon/volley
kill @e[type=marker,tag=orbital.target]
