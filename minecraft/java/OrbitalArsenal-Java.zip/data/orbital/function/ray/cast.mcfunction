kill @e[type=marker,tag=orbital.target]
scoreboard players set @s orbital.range 150
execute anchored eyes positioned ^ ^ ^1 run function orbital:ray/step
