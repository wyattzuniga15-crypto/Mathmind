scoreboard players remove @s orbital.range 1
execute if score @s orbital.range matches ..0 run function orbital:ray/land
execute if score @s orbital.range matches 1.. unless block ~ ~ ~ #orbital:passable run function orbital:ray/land
execute if score @s orbital.range matches 1.. if block ~ ~ ~ #orbital:passable positioned ^ ^ ^1 run function orbital:ray/step
