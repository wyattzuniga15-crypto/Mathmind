give @s carrot_on_a_stick
give @s warped_fungus_on_a_stick
give @s goat_horn
tellraw @s {"text":"Cannon, nuke and kamehameha — right-click to fire.","color":"aqua"}
