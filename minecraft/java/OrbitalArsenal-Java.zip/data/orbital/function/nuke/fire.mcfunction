scoreboard players set @s orbital.cd 400
title @s title {"text":"☢ DETONATION ☢","color":"dark_red","bold":true}
function orbital:ray/cast
execute at @e[type=marker,tag=orbital.target,limit=1] run function orbital:nuke/begin
kill @e[type=marker,tag=orbital.target]
