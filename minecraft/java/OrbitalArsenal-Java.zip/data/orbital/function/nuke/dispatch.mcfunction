execute at @e[type=marker,tag=orbital.crater,limit=1] run function orbital:nuke/carve
scoreboard players remove #orbital orbital.stage 1
execute if score #orbital orbital.stage matches ..0 run kill @e[type=marker,tag=orbital.crater]
