kill @e[type=marker,tag=orbital.crater]
summon marker ~ ~ ~ {Tags:["orbital.crater"]}
scoreboard players set #orbital orbital.stage 40
particle explosion_emitter ~ ~2 ~ 8 4 8 0 60 force
particle flash ~ ~2 ~ 6 3 6 0 25 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 100 0.5
playsound minecraft:entity.wither.death master @a ~ ~ ~ 100 0.6
