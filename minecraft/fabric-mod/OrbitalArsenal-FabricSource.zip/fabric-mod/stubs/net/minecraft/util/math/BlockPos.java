package net.minecraft.util.math;

public class BlockPos {
    public static BlockPos ofFloored(Vec3d v) { return null; }
    public static class Mutable extends BlockPos { public Mutable set(int x, int y, int z) { return this; } }
}
