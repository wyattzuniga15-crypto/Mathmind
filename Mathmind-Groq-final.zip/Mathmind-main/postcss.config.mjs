export default {
  plugins: {
    tailwindcss: {},

  },
};
