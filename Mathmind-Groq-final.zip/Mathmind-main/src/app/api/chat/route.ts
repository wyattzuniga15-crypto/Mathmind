import '@/lib/subjects';
import { getServerConfig } from '@/lib/core/env';
import { toAppError, AppError } from '@/lib/core/errors';
import { parseChatRequest } from '@/lib/core/validate';
import { resolveIdentity, clientKey } from '@/lib/core/auth';
import { rateLimiter, assertAllowed, rateLimitHeaders } from '@/lib/core/ratelimit';
import { getSubject } from '@/lib/core/registry';
import { AiClient, type ApiMessage, type ContentBlock } from '@/lib/core/ai/client';
import { runAgent } from '@/lib/core/ai/agent';
import { eventStreamResponse } from '@/lib/core/sse';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 300;

function toApiMessages(
  messages: { role: 'user' | 'assistant'; content: string; images?: { data: string; mediaType: string }[] }[],
): ApiMessage[] {
  return messages.map((message) => {
    if (!message.images?.length) {
      return { role: message.role, content: message.content };
    }

    const blocks: ContentBlock[] = [];
    if (message.content) {
      blocks.push({ type: 'text', text: message.content });
    }
    for (const image of message.images) {
      blocks.push({
        type: 'image',
        source: {
          type: 'base64',
          media_type: image.mediaType,
          data: image.data,
        },
      });
    }
    return { role: message.role, content: blocks };
  });
}

export async function POST(request: Request) {
  try {
    const config = getServerConfig();
    const parsed = parseChatRequest(await request.json());
    const subject = getSubject(parsed.subjectId);

    const { identity, setCookie } = await resolveIdentity(request, {
      required: config.authRequired,
    });

    const limit = await rateLimiter.check(clientKey(request, identity), [
      { name: 'chat_minute', limit: config.rateLimitPerMinute, windowMs: 60_000 },
      { name: 'chat_day', limit: config.rateLimitPerDay, windowMs: 86_400_000 },
    ]);
    assertAllowed(limit);

    const system = subject.buildSystemPrompt({
      mode: parsed.mode,
      level: parsed.level,
      memorySummary: parsed.memorySummary,
      sessionNotes: parsed.sessionNotes,
      hasImages: parsed.messages.some((m) => Boolean(m.images?.length)),
    });

    const client = new AiClient({
      apiKey: config.apiKey,
      baseUrl: config.apiBaseUrl,
      timeoutMs: config.requestTimeoutMs,
    });

    const events = runAgent({
      client,
      subject,
      system,
      messages: toApiMessages(parsed.messages),
      model: config.model,
      maxTokens: config.maxTokens,
      maxIterations: config.maxToolIterations,
      context: {
        subjectId: parsed.subjectId,
        mode: parsed.mode,
        level: parsed.level,
      },
    });

    const headers: Record<string, string> = {
      ...rateLimitHeaders(limit),
    };
    if (setCookie) headers['Set-Cookie'] = setCookie;

    return eventStreamResponse(events, { headers });
  } catch (error) {
    const appError = toAppError(
      error instanceof AppError ? error : error,
    );

    // The browser chat client expects SSE. Return the error as an SSE event
    // instead of JSON so it can display the actual Groq/configuration error.
    const events = (async function* () {
      yield {
        type: 'error' as const,
        message: appError.message,
        code: appError.code,
        retryable: appError.retryable,
      };
    })();

    return eventStreamResponse(events, {
      headers: {
        'X-MathMind-Error': appError.code,
      },
    });
  }
}
