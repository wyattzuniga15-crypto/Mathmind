import { AppError } from './errors';

/** Server-only configuration for the Groq-backed tutor. */
export interface ServerConfig {
  apiKey: string;
  apiBaseUrl: string;
  model: string;
  fastModel: string;
  maxTokens: number;
  requestTimeoutMs: number;
  maxToolIterations: number;
  rateLimitPerMinute: number;
  rateLimitPerDay: number;
  authRequired: boolean;
}

function env(name: string): string | undefined {
  const v = process.env[name];
  return v && v.trim() !== '' ? v.trim() : undefined;
}

function intEnv(name: string, fallback: number): number {
  const raw = env(name);
  if (!raw) return fallback;
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

export function getServerConfig(): ServerConfig {
  const apiKey = env('GROQ_API_KEY');
  if (!apiKey) {
    throw new AppError(
      'missing_api_key',
      'GROQ_API_KEY is not set. Add it in Vercel Environment Variables.',
      { status: 500 },
    );
  }

  const model = env('GROQ_MODEL') ?? 'openai/gpt-oss-20b';

  return {
    apiKey,
    apiBaseUrl: env('GROQ_BASE_URL') ?? 'https://api.groq.com/openai/v1',
    model,
    // Title generation uses the same model unless a separate model is supplied.
    fastModel: env('GROQ_FAST_MODEL') ?? model,
    // Keep the default modest to reduce Groq TPM usage.
    maxTokens: intEnv('AI_MAX_TOKENS', 2048),
    requestTimeoutMs: intEnv('AI_TIMEOUT_MS', 120_000),
    maxToolIterations: intEnv('AI_MAX_TOOL_ITERATIONS', 6),
    rateLimitPerMinute: intEnv('RATE_LIMIT_PER_MINUTE', 20),
    rateLimitPerDay: intEnv('RATE_LIMIT_PER_DAY', 500),
    authRequired: env('AUTH_REQUIRED') === 'true',
  };
}

export function isConfigured(): boolean {
  return Boolean(env('GROQ_API_KEY'));
}
