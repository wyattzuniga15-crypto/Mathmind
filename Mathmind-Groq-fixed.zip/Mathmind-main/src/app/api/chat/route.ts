import '@/lib/subjects';
import { getServerConfig } from '@/lib/core/env';
import { toAppError, AppError } from '@/lib/core/errors';
import { parseChatRequest } from '@/lib/core/validate';
import { resolveIdentity, clientKey } from '@/lib/core/auth';
import { rateLimiter, assertAllowed, rateLimitHeaders } from '@/lib/core/ratelimit';
import { getSubject } from '@/lib/core/registry';
import { AiClient } from '@/lib/core/ai/client';
import { runAgent } from '@/lib/core/ai/agent';
import { eventStreamResponse } from '@/lib/core/sse';
import type { ApiMessage, ContentBlock } from '@/lib/core/ai/client';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function toApiMessages(messages: ReturnType<typeof parseChatRequest>['messages']): ApiMessage[] {
  return messages.map((message) => {
    if (!message.images?.length) return { role: message.role, content: message.content };
    const content: ContentBlock[] = [];
    if (message.content.trim()) content.push({ type: 'text', text: message.content });
    for (const image of message.images) content.push({ type: 'image', source: { type: 'base64', media_type: image.mediaType, data: image.data } });
    return { role: message.role, content };
  });
}

export async function POST(request: Request) {
  try {
    const config = getServerConfig();
    const { identity, setCookie } = await resolveIdentity(request, { required: config.authRequired });
    const limit = await rateLimiter.check(clientKey(request, identity), [
      { name: 'chat_minute', limit: config.rateLimitPerMinute, windowMs: 60_000 },
      { name: 'chat_day', limit: config.rateLimitPerDay, windowMs: 86_400_000 },
    ]);
    assertAllowed(limit);

    let body: unknown;
    try { body = await request.json(); } catch { throw new AppError('invalid_request', 'Request body must be valid JSON.'); }
    const parsed = parseChatRequest(body);
    const subject = getSubject(parsed.subjectId);
    const system = subject.buildSystemPrompt({ mode: parsed.mode, level: parsed.level, memorySummary: parsed.memorySummary, sessionNotes: parsed.sessionNotes, hasImages: parsed.messages.some((m) => Boolean(m.images?.length)) });
    const client = new AiClient({ apiKey: config.apiKey, baseUrl: config.apiBaseUrl, timeoutMs: config.requestTimeoutMs });
    const events = runAgent({
      client, subject, system, messages: toApiMessages(parsed.messages), model: config.model,
      maxTokens: config.maxTokens, maxIterations: config.maxToolIterations,
      context: { subjectId: parsed.subjectId, mode: parsed.mode, level: parsed.level }, signal: request.signal,
    });
    return eventStreamResponse(events, { headers: { ...rateLimitHeaders(limit), ...(setCookie ? { 'Set-Cookie': setCookie } : {}) } });
  } catch (err) {
    const appError = toAppError(err);
    return Response.json(appError.toJSON(), { status: appError.status });
  }
}
