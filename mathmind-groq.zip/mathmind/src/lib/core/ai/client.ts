import { AppError } from '../errors';
import type { ToolDefinition } from '../types';

/**
 * Dependency-free client for Groq's OpenAI-compatible Chat Completions API.
 *
 * The browser never calls Groq directly. This class is imported only by
 * server-side route handlers and receives the secret from core/env.ts.
 */

export type ContentBlock =
  | { type: 'text'; text: string }
  | { type: 'image'; source: { type: 'base64'; media_type: string; data: string } }
  | { type: 'tool_use'; id: string; name: string; input: unknown }
  | { type: 'tool_result'; tool_use_id: string; content: string; is_error?: boolean };

export interface ApiMessage {
  role: 'user' | 'assistant';
  content: string | ContentBlock[];
}

export interface CompletionRequest {
  model: string;
  system: string;
  messages: ApiMessage[];
  tools?: ToolDefinition[];
  maxTokens: number;
  temperature?: number;
  signal?: AbortSignal;
}

export interface AssistantTurn {
  content: ContentBlock[];
  stopReason: string | null;
  usage: { inputTokens: number; outputTokens: number };
}

/** Events surfaced while a single model turn streams in. */
export type ModelStreamEvent =
  | { type: 'text_delta'; text: string }
  | { type: 'tool_use_start'; id: string; name: string }
  | { type: 'turn_complete'; turn: AssistantTurn };

export interface AiClientOptions {
  apiKey: string;
  baseUrl?: string;
  timeoutMs?: number;
  /** Injectable for tests. */
  fetchImpl?: typeof fetch;
}

type GroqMessage =
  | { role: 'system'; content: string }
  | { role: 'user'; content: string | GroqContentPart[] }
  | {
      role: 'assistant';
      content: string | null;
      tool_calls?: GroqToolCall[];
    }
  | { role: 'tool'; tool_call_id: string; content: string };

interface GroqContentPart {
  type: 'text' | 'image_url';
  text?: string;
  image_url?: { url: string };
}

interface GroqToolCall {
  id: string;
  type: 'function';
  function: { name: string; arguments: string };
}

interface GroqToolDefinition {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: ToolDefinition['input_schema'];
  };
}

interface StreamToolState {
  id: string;
  name: string;
  arguments: string;
}

export class AiClient {
  private apiKey: string;
  private baseUrl: string;
  private timeoutMs: number;
  private fetchImpl: typeof fetch;

  constructor(options: AiClientOptions) {
    this.apiKey = options.apiKey;
    this.baseUrl = (options.baseUrl ?? 'https://api.groq.com/openai/v1').replace(/\/$/, '');
    this.timeoutMs = options.timeoutMs ?? 120_000;
    this.fetchImpl = options.fetchImpl ?? fetch;
  }

  private mapTool(tool: ToolDefinition): GroqToolDefinition {
    return {
      type: 'function',
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.input_schema,
      },
    };
  }

  /**
   * Converts the app's provider-neutral transcript into the OpenAI-compatible
   * message format used by Groq. Tool results become `role: tool` messages,
   * while assistant tool uses become `tool_calls`.
   */
  private mapMessages(request: CompletionRequest): GroqMessage[] {
    const out: GroqMessage[] = [{ role: 'system', content: request.system }];

    for (const message of request.messages) {
      if (typeof message.content === 'string') {
        out.push({ role: message.role, content: message.content });
        continue;
      }

      if (message.role === 'assistant') {
        const text = message.content
          .filter((b): b is Extract<ContentBlock, { type: 'text' }> => b.type === 'text')
          .map((b) => b.text)
          .join('');
        const toolCalls = message.content
          .filter((b): b is Extract<ContentBlock, { type: 'tool_use' }> => b.type === 'tool_use')
          .map((b) => ({
            id: b.id,
            type: 'function' as const,
            function: {
              name: b.name,
              arguments: JSON.stringify(b.input ?? {}),
            },
          }));

        out.push({
          role: 'assistant',
          content: text || null,
          ...(toolCalls.length ? { tool_calls: toolCalls } : {}),
        });
        continue;
      }

      const toolResults = message.content.filter(
        (b): b is Extract<ContentBlock, { type: 'tool_result' }> => b.type === 'tool_result',
      );
      const hasToolResults = toolResults.length > 0;

      for (const result of toolResults) {
        out.push({
          role: 'tool',
          tool_call_id: result.tool_use_id,
          content: result.content,
        });
      }

      const regularParts: GroqContentPart[] = [];
      for (const block of message.content) {
        if (block.type === 'text') regularParts.push({ type: 'text', text: block.text });
        if (block.type === 'image') {
          regularParts.push({
            type: 'image_url',
            image_url: {
              url: `data:${block.source.media_type};base64,${block.source.data}`,
            },
          });
        }
      }

      if (regularParts.length && !hasToolResults) {
        out.push({ role: 'user', content: regularParts });
      }
    }

    return out;
  }

  private buildBody(request: CompletionRequest, stream: boolean): Record<string, unknown> {
    const body: Record<string, unknown> = {
      model: request.model,
      messages: this.mapMessages(request),
      max_tokens: request.maxTokens,
      stream,
    };

    if (request.tools?.length) {
      body.tools = request.tools.map((tool) => this.mapTool(tool));
      body.tool_choice = 'auto';
    }

    if (typeof request.temperature === 'number') body.temperature = request.temperature;
    if (stream) body.stream_options = { include_usage: true };
    return body;
  }

  private async send(request: CompletionRequest, stream: boolean): Promise<Response> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);

    if (request.signal) {
      if (request.signal.aborted) controller.abort();
      else request.signal.addEventListener('abort', () => controller.abort(), { once: true });
    }

    let response: Response;
    try {
      response = await this.fetchImpl(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify(this.buildBody(request, stream)),
        signal: controller.signal,
      });
    } catch (err) {
      clearTimeout(timer);
      if (request.signal?.aborted) throw new AppError('aborted', 'Generation was stopped.', { status: 499 });
      if ((err as Error)?.name === 'AbortError') {
        throw new AppError('timeout', 'The AI service did not respond in time.');
      }
      throw new AppError('upstream_error', `Could not reach the AI service: ${(err as Error).message}`);
    }
    clearTimeout(timer);

    if (!response.ok) {
      const text = await response.text().catch(() => '');
      throw mapHttpError(response.status, text);
    }
    return response;
  }

  /** Non-streaming call, used for titles and the final fallback after tool exhaustion. */
  async complete(request: CompletionRequest): Promise<AssistantTurn> {
    const response = await this.send(request, false);
    const json = (await response.json()) as {
      choices?: Array<{
        message?: {
          content?: string | null;
          tool_calls?: GroqToolCall[];
        };
        finish_reason?: string | null;
      }>;
      usage?: { prompt_tokens?: number; completion_tokens?: number };
    };

    const message = json.choices?.[0]?.message;
    const content: ContentBlock[] = [];

    if (message?.content) content.push({ type: 'text', text: message.content });
    for (const call of message?.tool_calls ?? []) {
      content.push({
        type: 'tool_use',
        id: call.id,
        name: call.function.name,
        input: parseToolArguments(call.function.arguments),
      });
    }

    return {
      content,
      stopReason: json.choices?.[0]?.finish_reason ?? null,
      usage: {
        inputTokens: json.usage?.prompt_tokens ?? 0,
        outputTokens: json.usage?.completion_tokens ?? 0,
      },
    };
  }

  /** Streams one assistant turn and reassembles fragmented tool calls. */
  async *stream(request: CompletionRequest): AsyncGenerator<ModelStreamEvent> {
    const response = await this.send(request, true);
    if (!response.body) throw new AppError('upstream_error', 'The AI service returned an empty stream.');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    const textBlocks: string[] = [];
    const toolCalls = new Map<number, StreamToolState>();
    let stopReason: string | null = null;
    let inputTokens = 0;
    let outputTokens = 0;

    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newline: number;
        while ((newline = buffer.indexOf('\n')) !== -1) {
          const line = buffer.slice(0, newline).replace(/\r$/, '');
          buffer = buffer.slice(newline + 1);

          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const raw = trimmed.slice(5).trim();
          if (!raw || raw === '[DONE]') continue;

          let event: Record<string, unknown>;
          try {
            event = JSON.parse(raw);
          } catch {
            continue;
          }

          const choices = Array.isArray(event.choices) ? event.choices : [];
          const choice = (choices[0] ?? {}) as {
            delta?: {
              content?: string | null;
              tool_calls?: Array<{
                index: number;
                id?: string;
                function?: { name?: string; arguments?: string };
              }>;
            };
            finish_reason?: string | null;
          };
          const delta = choice.delta;

          if (typeof delta?.content === 'string' && delta.content) {
            textBlocks.push(delta.content);
            yield { type: 'text_delta', text: delta.content };
          }

          for (const part of delta?.tool_calls ?? []) {
            const index = Number.isInteger(part.index) ? part.index : 0;
            let state = toolCalls.get(index);

            if (!state) {
              state = {
                id: part.id ?? `call_${Date.now()}_${index}`,
                name: part.function?.name ?? '',
                arguments: part.function?.arguments ?? '',
              };
              toolCalls.set(index, state);
              if (state.name) yield { type: 'tool_use_start', id: state.id, name: state.name };
            } else {
              if (part.id) state.id = part.id;
              if (part.function?.name) state.name += part.function.name;
              if (part.function?.arguments) state.arguments += part.function.arguments;
            }
          }

          if (choice.finish_reason) stopReason = choice.finish_reason;

          const usage = event.usage as
            | { prompt_tokens?: number; completion_tokens?: number }
            | undefined;
          if (usage) {
            inputTokens = usage.prompt_tokens ?? inputTokens;
            outputTokens = usage.completion_tokens ?? outputTokens;
          }
        }
      }

      // Some providers can end without a final newline.
      const final = buffer.trim();
      if (final.startsWith('data:')) {
        try {
          const event = JSON.parse(final.slice(5).trim()) as {
            choices?: Array<{ finish_reason?: string | null }>;
            usage?: { prompt_tokens?: number; completion_tokens?: number };
          };
          stopReason = event.choices?.[0]?.finish_reason ?? stopReason;
          inputTokens = event.usage?.prompt_tokens ?? inputTokens;
          outputTokens = event.usage?.completion_tokens ?? outputTokens;
        } catch {
          /* Ignore an incomplete trailing frame. */
        }
      }
    } finally {
      reader.releaseLock?.();
    }

    const blocks: ContentBlock[] = textBlocks.length
      ? [{ type: 'text', text: textBlocks.join('') }]
      : [];

    for (const [, call] of [...toolCalls.entries()].sort(([a], [b]) => a - b)) {
      blocks.push({
        type: 'tool_use',
        id: call.id,
        name: call.name,
        input: parseToolArguments(call.arguments),
      });
    }

    yield {
      type: 'turn_complete',
      turn: {
        content: blocks,
        stopReason,
        usage: { inputTokens, outputTokens },
      },
    };
  }
}

function parseToolArguments(raw: string): Record<string, unknown> {
  if (!raw.trim()) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}

function mapHttpError(status: number, body: string): AppError {
  let message = body;
  try {
    const parsed = JSON.parse(body) as { error?: { message?: string; type?: string } };
    if (parsed.error?.message) message = parsed.error.message;
  } catch {
    /* keep raw body */
  }

  const short = message.slice(0, 400) || `HTTP ${status}`;
  if (status === 401 || status === 403) {
    return new AppError('unauthorized', `The AI service rejected the API key: ${short}`, { status: 500 });
  }
  if (status === 429) return new AppError('rate_limited', `Rate limited by the AI service: ${short}`);
  if (status === 400) return new AppError('invalid_request', `The AI service rejected the request: ${short}`);
  if (status === 408 || status === 504) return new AppError('timeout', 'The AI service timed out.');
  if (status === 500 || status === 502 || status === 503 || status === 529) {
    return new AppError('upstream_overloaded', 'The AI service is temporarily unavailable.');
  }
  return new AppError('upstream_error', `AI service error (${status}): ${short}`);
}
